package com.leige.Entity;

public class User {
   private Long id;
   private String user_name;
   private String user_id ;
   private String user_class;
   private String user_biaoxian;
   private String user_bo;
   private String user_bt;
   private String user_bth;
   private String user_bf;
   private String user_chengji;
   private String user_chengjio;
   private String user_chengjit;
   private String user_chengjith;
   private String user_chengjif;
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getUser_name() {
	return user_name;
}
public void setUser_name(String user_name) {
	this.user_name = user_name;
}
public String getUser_bo() {
	return user_bo;
}
public void setUser_bo(String user_b_o) {
	this.user_bo = user_b_o;
}
public String getUser_bt() {
	return user_bt;
}
public void setUser_bt(String user_bt) {
	this.user_bt = user_bt;
}
public String getUser_bth() {
	return user_bth;
}
public void setUser_bth(String user_bth) {
	this.user_bth = user_bth;
}
public String getUser_bf() {
	return user_bf;
}
public void setUser_bf(String user_bf) {
	this.user_bf = user_bf;
}
public String getUser_chengjio() {
	return user_chengjio;
}
public void setUser_chengjio(String user_chengjio) {
	this.user_chengjio = user_chengjio;
}
public String getUser_chengjit() {
	return user_chengjit;
}
public void setUser_chengjit(String user_chengjit) {
	this.user_chengjit = user_chengjit;
}
public String getUser_chengjith() {
	return user_chengjith;
}
public void setUser_chengjith(String user_chengjith) {
	this.user_chengjith = user_chengjith;
}
public String getUser_chengjif() {
	return user_chengjif;
}
public void setUser_chengjif(String user_chengjif) {
	this.user_chengjif = user_chengjif;
}
public String getUser_id() {
	return user_id;
}
public void setUser_id(String user_id) {
	this.user_id = user_id;
}
public String getUser_class() {
	return user_class;
}
public void setUser_class(String user_class) {
	this.user_class = user_class;
}
public String getUser_biaoxian() {
	return user_biaoxian;
}
public void setUser_biaoxian(String user_biaoxian) {
	this.user_biaoxian = user_biaoxian;
}
public String getUser_chengji() {
	return user_chengji;
}
public void setUser_chengji(String user_chengji) {
	this.user_chengji = user_chengji;
}
public void getChji(){
	// ��ʽ�������ɼ���Ȼ���أ����ݣ��ֱ���飻����������
	String uscore=this.user_chengji;
    StringBuffer ss = new StringBuffer();
  System.out.println(ss);
    if (ss!= null && !ss.equals("")){
       String[] sc=uscore.split(";");
      // �����һ���������ÿһ�����ݶ��ǿյģ���δ�����
       // ʲô�����ܣ�ֱ�Ӽ�һ���ո�
    	   this.user_chengjio=sc[0];
    	   this.user_chengjit=sc[1];
    	   this.user_chengjith=sc[2];
    	   this.user_chengjif=sc[3];      
}
    String ub=this.user_biaoxian;
    if (ub!= null && !ub.equals("")){
        String[] sc=ub.split(";");
        System.out.println(ub);
        System.out.println(sc[1]);
        if (sc[0].equals("")||sc[0]== null){
        	this.user_bo=" ";
        }
        else{
        	this.user_bo=sc[0];
        }    
        if (sc[1].equals("")||sc[1]== null){
        	this.user_bt=" ";
        }
        else{
        	this.user_bt=sc[1];
        }    
        if (sc[2].equals("")||sc[2]== null){
        	this.user_bth=" ";
        }
        else{
        	this.user_bth=sc[2];
        }    
        if (sc[3].equals("")||sc[3]== null){
        	this.user_bf=" ";
        }
        else{
        	this.user_bf=sc[3];
        }    
          
        
          
 }
    
}
    public void setChji(){
    	// ��ΰ������ĸ������ֵ����ݷŵ�һ��set��;
    	// ��ʽ�������ɼ���Ȼ���أ����ݣ��ֱ���飻����������
        this.user_chengji=this.user_chengjio+";"+this.user_chengjit+";"+this.user_chengjith+";"+this.user_chengjif;
        
    	
    }
    public void setBx(){
    	this.user_biaoxian=this.user_bo+";"+this.user_bt+";"+this.user_bth+";"+this.user_bf;
        
    }
    }
