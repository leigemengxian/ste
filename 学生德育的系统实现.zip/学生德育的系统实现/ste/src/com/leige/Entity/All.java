package com.leige.Entity;

public class All {
        String search_user_id;
        String search_total;
        Long id;
        String class_id;
        String user_name;
        String user_id;
		String user_biaoxiano;
        String user_biaoxiant;
        String user_biaoxianth;
        String user_biaoxianf;
        String user_scoreo;
        String user_scoret;
        String user_scoreth;
        String user_scoref;
		public String getUser_biaoxiano() {
			return user_biaoxiano;
		}
		public void setUser_biaoxiano(String user_biaoxiano) {
			if (user_biaoxiano.equals("")){this.user_biaoxiano=" ";}
			this.user_biaoxiano = user_biaoxiano;
		}
		public String getUser_biaoxiant() {
			
			return user_biaoxiant;
		}
		public void setUser_biaoxiant(String user_biaoxiant) {
			if (user_biaoxiant.equals("")){this.user_biaoxiant=" ";}
			this.user_biaoxiant = user_biaoxiant;
		}
		public String getUser_biaoxianth() {
			return user_biaoxianth;
		}
		public void setUser_biaoxianth(String user_biaoxianth) {
			if (user_biaoxianth.equals("")){this.user_biaoxianth=" ";}
			this.user_biaoxianth = user_biaoxianth;
		}
		public String getUser_biaoxianf() {
			return user_biaoxianf;
		}
		public void setUser_biaoxianf(String user_biaoxianf) {
			if (user_biaoxianf.equals("")){this.user_biaoxianf=" ";}
			this.user_biaoxianf = user_biaoxianf;
		}
		public String getUser_scoreo() {
			return user_scoreo;
		}
		public void setUser_scoreo(String user_scoreo) {
			if (user_scoreo.equals("")){this.user_scoreo=" ";}
			this.user_scoreo = user_scoreo;
		}
		public String getUser_scoret() {
			return user_scoret;
		}
		public void setUser_scoret(String user_scoret) {
			if (user_scoret.equals("")){this.user_scoret=" ";}
			this.user_scoret = user_scoret;
		}
		public String getUser_scoreth() {
			return user_scoreth;
		}
		public void setUser_scoreth(String user_scoreth) {
			if (user_scoreth.equals("")){this.user_scoreth=" ";}
			this.user_scoreth = user_scoreth;
		}
		public String getUser_scoref() {
			return user_scoref;
		}
		public void setUser_scoref(String user_scoref) {
			if (user_scoref.equals("")){this.user_scoref=" ";}
			this.user_scoref = user_scoref;
		}
		public String getSearch_user_id() {
			return search_user_id;
		}
		public void setSearch_user_id(String search_user_id) {
			this.search_user_id = search_user_id;
		}
		public String getSearch_total() {
			return search_total;
		}
		public void setSearch_total(String search_total) {
			this.search_total = search_total;
		}
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getClass_id() {
			return class_id;
		}
		public void setClass_id(String class_id) {
			this.class_id = class_id;
		}
		public String getUser_name() {
			return user_name;
		}
		public void setUser_name(String user_name) {
			this.user_name = user_name;
		}
		public String getUser_id() {
			return user_id;
		}
		public void setUser_id(String user_id) {
			this.user_id = user_id;
		}
		
        
        
}
