package com.leige.Dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

import com.leige.Entity.User;

public interface UserDao {
    public void save(Connection conn,User user);
    public void update(Connection conn,User user);
    public void delete(Connection conn, User user);
    public ResultSet  get (Connection conn, User user);
    public ResultSet getuser(Connection conn,Long id);
    public ResultSet gettextwrite(Connection conn,Long id );
	public void updatetext(Connection conn, Long id, String text);
    public ResultSet getbyId(Connection conn, Long id);
    public List<User> getAll(Connection conn,String xingming);
    public List<User> getAll(Connection conn);
    public List<User> getAll(Connection conn,String xingming,String what);

    
}
