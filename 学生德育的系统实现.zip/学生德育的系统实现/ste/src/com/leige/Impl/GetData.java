package com.leige.Impl;

public class GetData {

}
