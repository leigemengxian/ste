package com.leige.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.leige.Dao.UserDao;
import com.leige.Entity.User;


public class UserImpl implements UserDao {

	
	
	/* �����û���Ϣ*/
	@Override
	public void save(Connection conn, User user) {
	  try {
		PreparedStatement ps=conn.prepareCall("INSERT INTO tbl_user(user_name,user_id,user_class,user_biaoxian,user_chengji)  values(?,?,?,?,?)");
		ps.setString(1, user.getUser_name());
		ps.setString(2,user.getUser_id());
		ps.setString(3, user.getUser_class());
		ps.setString(4, user.getUser_biaoxian());
		ps.setString(5, user.getUser_chengji());
		
		ps.execute();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	}

	
	/* �����û��ṩ��Id, �����û���ȫ����Ϣ*/
	@Override
	public void update(Connection conn,  User user) {
         String sql="UPDATE tbl_user SET user_name=? , user_id=?,user_class=?,user_biaoxian=?,user_chengji=? WHERE id=?";
         try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, user.getUser_name());
			ps.setString(2,user.getUser_id());
			ps.setString(3, user.getUser_class());
			ps.setString(4, user.getUser_biaoxian());
			ps.setString(5, user.getUser_chengji());
			ps.setLong(6,user.getId());
			System.out.println(ps);
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         

	}

	/* �����û���������Ϣ*/
	public void updatetext(Connection conn, Long id, String text) {
        String sql="UPDATE tbl_user SET user_nowlearning=? WHERE id=?";
        try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, text);
			ps.setLong(2, id);
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        

	}
	
	
	
	
	
	
	
	/* �����û��ṩ��id �� ɾ���û�����Ϣ*/
	@Override
	public void delete(Connection conn, User user) {
		 String sql="DELETE  FROM tbl_user where id =?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
		
			ps.setLong(1,user.getId());
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	@Override
	public ResultSet get(Connection conn, User user) {
		// TODO Auto-generated method stub
		String sql="SELECT * FROM tbl_user WHERE user_name=? and user_password=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
		    ps.setString(1, user.getUser_name());
            ps.setString(2, user.getUser_id());
			
			return  ps.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public ResultSet getuser(Connection conn, Long  id) {
		String sql="SELECT * FROM tbl_user WHERE id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
		    
			ps.setLong(1, id);
			return  ps.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}



	@Override
	public ResultSet gettextwrite(Connection conn, Long id) {
		// TODO Auto-generated method stub
		String sql="SELECT * FROM tbl_user WHERE id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
		    
			ps.setLong(1, id);
			return  ps.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public ResultSet getbyId(Connection conn, Long id) {
		// TODO Auto-generated method stub
		
		
		String sql="SELECT * FROM tbl_user WHERE id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
		    
			ps.setLong(1, id);
			return  ps.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


	


	@Override
	public List<User> getAll(Connection conn, String xx, String what) {
		List<User> list=new ArrayList<User>();
		String sql="SELECT * FROM tbl_user where ? =?";
		
		try{
			PreparedStatement ps=conn.prepareStatement(sql);
			 ps.setString(1, what);
			 ps.setString(2, xx);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				User video=new User();
			
				video.setId(rs.getLong(1));
				video.setUser_class(rs.getString(2));
				video.setUser_name(rs.getString(3));
				video.setUser_id(rs.getString(4));
				video.setUser_biaoxian(rs.getString(5));
				video.setUser_chengji(rs.getString(6));
				
				list.add(video);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return list;
		
	}


	@Override
	public List<User> getAll(Connection conn, String xingming) {
		// TODO Auto-generated method stub
		List<User> list=new ArrayList<User>();
		String sql="SELECT * FROM tbl_user where user_name =?";
		try{
			PreparedStatement ps=conn.prepareStatement(sql);
			 ps.setString(1, xingming);
			
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()){
				User video=new User();
			
				video.setId(rs.getLong(1));
				
				video.setUser_name(rs.getString(2));
				video.setUser_id(rs.getString(3));
				video.setUser_class(rs.getString(4));
				video.setUser_biaoxian(rs.getString(5));
				video.setUser_chengji(rs.getString(6));
				System.out.println("one"+video.getUser_chengji());
				list.add(video);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return list;
		
	}


	@Override
	public List<User> getAll(Connection conn) {
		// TODO Auto-generated method stub
		List<User> list=new ArrayList<User>();
		String sql="SELECT id,user_name,user_id,user_class,user_biaoxian,user_chengji FROM tbl_user ";
		
		try{
			PreparedStatement ps=conn.prepareStatement(sql);
			
			
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				User video=new User();
			
				video.setId(rs.getLong(1));
				video.setUser_class(rs.getString(4));
				video.setUser_name(rs.getString(2));
				video.setUser_id(rs.getString(3));
				video.setUser_biaoxian(rs.getString(5));
				video.setUser_chengji(rs.getString(6));
				System.out.println(video.getUser_name());
				list.add(video);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return list;
		
	
	}
	}


