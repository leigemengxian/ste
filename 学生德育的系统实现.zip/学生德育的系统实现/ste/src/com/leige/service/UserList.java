package com.leige.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import com.leige.Dao.*;
import com.leige.Entity.*;
import com.leige.Impl.UserImpl;
import com.leige.util.ConnectionFactory;

public class UserList {
	 private UserDao videodao=new UserImpl();
	 public List<User> getAll( String s){
		 Connection conn=ConnectionFactory.getInstance().makeConnect();
		 try {
				conn.setAutoCommit(false);
				  List <User> vdlist=videodao.getAll(conn,s);
			    return vdlist;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				try {
					conn.close();
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return null;
		
			  
		  }
	 
	 public List<User> getAll( ){
		 Connection conn=ConnectionFactory.getInstance().makeConnect();
		 try {
				conn.setAutoCommit(false);
				  List <User> vdlist=videodao.getAll(conn);
			    return vdlist;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				try {
					conn.close();
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return null;
		
			  
		  }
	 public  User getUser(User user){
		  Connection conn=ConnectionFactory.getInstance().makeConnect();
		   User u=new  User();
		  UserImpl xe=new UserImpl();
		  try {
			conn.setAutoCommit(false);
			ResultSet resutlt=xe.getuser(conn, user.getId());
			while(resutlt.next()){
				u.setId(resutlt.getLong(1));
				u.setUser_name(resutlt.getString(2));
				u.setUser_id(resutlt.getString(3));
				u.setUser_class(resutlt.getString(4));
				u.setUser_biaoxian(resutlt.getString(5));
				u.setUser_chengji(resutlt.getString(6));
			    //ԭ����ʱ��ֻ�ǽ����ĳɼ���Ȼ��������Ҫ��д�����ļ�������Ȼ������������õ���
				u.getChji();
				System.out.println("������Ϣ"+u.getUser_bo());
				return u;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		  return null;
		  
	  }
	  
	
			  public void update(User user){
				  Connection conn=ConnectionFactory.getInstance().makeConnect();
				  try {
					conn.setAutoCommit(false);
					videodao.update(conn, user);
					//videodao.delete(conn, user);
					 conn.commit();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					  
				}finally{
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						
					}
				}
				
			  }
			  public void delete(User user){
				  Connection conn=ConnectionFactory.getInstance().makeConnect();
				  try {
					conn.setAutoCommit(false);
					videodao.delete(conn, user);
					 conn.commit();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					  
				}finally{
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						
					}
				}
				
			  }


			public void insert(User x) {
				// TODO Auto-generated method stub
				 Connection conn=ConnectionFactory.getInstance().makeConnect();
				  try {
					conn.setAutoCommit(false);
					videodao.save(conn, x);
					//videodao.delete(conn, user);
					 conn.commit();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					  
				}finally{
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						
					}
				}
			}
		 
}
