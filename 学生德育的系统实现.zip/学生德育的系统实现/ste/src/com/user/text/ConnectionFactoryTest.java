package com.user.text;

import java.sql.Connection;
import java.sql.SQLException;

import com.leige.util.ConnectionFactory;

public class ConnectionFactoryTest {
 public static void main(String[] args) {
	ConnectionFactory con=ConnectionFactory.getInstance();
	Connection conn=con.makeConnect();
	try {
		System.out.println(conn.getAutoCommit());
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
