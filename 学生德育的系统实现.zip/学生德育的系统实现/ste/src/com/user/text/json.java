package com.user.text;
import com.leige.Entity.*;
import com.alibaba.fastjson.JSON;
public class json {
	public static void main(){
		User a=new User();
		a.setId((long)12);
		
		
	
		a.setUser_name("admin");

		User guestUser = new User();
		guestUser.setId(2L);
		guestUser.setUser_name("guest");

		User rootUser = new User();
		rootUser.setId(3L);
		rootUser.setUser_name("root");

		

		String jsonString = JSON.toJSONString(rootUser);

		System.out.println(jsonString);

	}
 
  
}
