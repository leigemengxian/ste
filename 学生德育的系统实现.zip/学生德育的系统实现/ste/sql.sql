create table tbl_user(
id int (11) unsigned not null auto_increment,
user_name varchar(50) not null default '',
user_id varchar(50) not null default '',
user_class varchar(50) null default '',
user_biaoxian varchar(8000) null default ' ; ; ; ',
user_chengji varchar(8000) null default ' ; ; ; ',
user_lan varchar(800) null default'��������е���',
primary key (id))
engine=InnoDB
default charset=utf8;